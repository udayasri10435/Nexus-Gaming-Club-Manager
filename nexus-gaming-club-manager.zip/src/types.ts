export type ServiceStatus = 'online' | 'offline' | 'warning';

export interface Microservice {
  id: string;
  name: string;
  domain: string;
  language: string;
  status: ServiceStatus;
  latency: number;
  uptime: string;
}

export interface Member {
  id: string;
  username: string;
  email: string;
  joinedDate: string;
  rank: string;
  status: 'active' | 'inactive' | 'banned';
  lastSeen: string;
}

export interface Tournament {
  id: string;
  name: string;
  game: string;
  participants: number;
  status: 'upcoming' | 'ongoing' | 'completed';
  prizePool: string;
}

export interface Game {
  id: string;
  title: string;
  genre: string;
  activePlayers: number;
  rating: number;
  image: string;
}
