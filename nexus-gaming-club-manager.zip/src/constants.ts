import { Microservice, Member, Tournament, Game } from './types';

export const MOCK_SERVICES: Microservice[] = [
  { id: '1', name: 'user-registry', domain: 'User & Identity', language: 'Java', status: 'online', latency: 45, uptime: '99.9%' },
  { id: '2', name: 'authentication', domain: 'User & Identity', language: 'Go', status: 'online', latency: 12, uptime: '100%' },
  { id: '3', name: 'matchmaker', domain: 'Game Management', language: 'Rust', status: 'warning', latency: 150, uptime: '98.5%' },
  { id: '4', name: 'wallet-service', domain: 'Payments', language: 'Kotlin', status: 'online', latency: 30, uptime: '99.99%' },
  { id: '5', name: 'chat-engine', domain: 'Social', language: 'Erlang', status: 'online', latency: 8, uptime: '99.99%' },
  { id: '6', name: 'fraud-detector', domain: 'Payments', language: 'Python', status: 'online', latency: 200, uptime: '99.5%' },
  { id: '7', name: 'bracket-engine', domain: 'Tournament', language: 'Elixir', status: 'offline', latency: 0, uptime: '95.0%' },
  { id: '8', name: 'event-collector', domain: 'Analytics', language: 'Go', status: 'online', latency: 15, uptime: '99.9%' },
];

export const MOCK_MEMBERS: Member[] = [
  { id: 'm1', username: 'ShadowBlade', email: 'shadow@example.com', joinedDate: '2023-10-12', rank: 'Diamond', status: 'active', lastSeen: '2 mins ago' },
  { id: 'm2', username: 'CyberPunk', email: 'cyber@example.com', joinedDate: '2023-11-05', rank: 'Gold', status: 'active', lastSeen: '1 hour ago' },
  { id: 'm3', username: 'NeonGhost', email: 'ghost@example.com', joinedDate: '2024-01-20', rank: 'Platinum', status: 'inactive', lastSeen: '3 days ago' },
  { id: 'm4', username: 'RogueOne', email: 'rogue@example.com', joinedDate: '2023-09-15', rank: 'Silver', status: 'active', lastSeen: 'Now' },
  { id: 'm5', username: 'ToxicAvenger', email: 'toxic@example.com', joinedDate: '2024-02-10', rank: 'Bronze', status: 'banned', lastSeen: '1 month ago' },
];

export const MOCK_TOURNAMENTS: Tournament[] = [
  { id: 't1', name: 'Cyber Cup 2026', game: 'Apex Legends', participants: 64, status: 'ongoing', prizePool: '$5,000' },
  { id: 't2', name: 'Winter Brawl', game: 'Street Fighter 6', participants: 32, status: 'upcoming', prizePool: '$1,200' },
  { id: 't3', name: 'Global Elite Masters', game: 'CS2', participants: 128, status: 'completed', prizePool: '$10,000' },
];

export const MOCK_GAMES: Game[] = [
  { id: 'g1', title: 'Cyber Strike', genre: 'FPS', activePlayers: 1240, rating: 4.8, image: 'https://picsum.photos/seed/cyber/400/225' },
  { id: 'g2', title: 'Neon Racer', genre: 'Racing', activePlayers: 850, rating: 4.5, image: 'https://picsum.photos/seed/racing/400/225' },
  { id: 'g3', title: 'Void Quest', genre: 'RPG', activePlayers: 2100, rating: 4.9, image: 'https://picsum.photos/seed/rpg/400/225' },
];
