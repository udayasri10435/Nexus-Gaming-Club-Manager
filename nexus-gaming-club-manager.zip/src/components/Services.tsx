import React, { useState, useEffect, useRef } from 'react';
import { MOCK_SERVICES } from '../constants';
import { cn } from '../lib/utils';
import { Search, Filter, Activity, Cpu, Database, Globe, AlertTriangle, XCircle, RefreshCw, X, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import { Microservice, ServiceStatus } from '../types';

interface ServiceAlert {
  id: string;
  serviceId: string;
  serviceName: string;
  status: ServiceStatus;
  message: string;
  timestamp: string;
}

export const Services: React.FC = () => {
  const [services, setServices] = useState<Microservice[]>(MOCK_SERVICES);
  const [filter, setFilter] = useState<ServiceStatus | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [alerts, setAlerts] = useState<ServiceAlert[]>([]);
  const prevStatuses = useRef<Record<string, ServiceStatus>>({});

  // Initialize previous statuses
  useEffect(() => {
    const statuses: Record<string, ServiceStatus> = {};
    services.forEach(s => {
      statuses[s.id] = s.status;
    });
    prevStatuses.current = statuses;
  }, []);

  // Monitor status changes
  useEffect(() => {
    services.forEach(service => {
      const prevStatus = prevStatuses.current[service.id];
      if (prevStatus && prevStatus !== service.status) {
        if (service.status === 'offline') {
          const alertId = `${service.id}-offline-${Date.now()}`;
          const newAlert: ServiceAlert = {
            id: alertId,
            serviceId: service.id,
            serviceName: service.name,
            status: 'offline',
            message: `CRITICAL: ${service.name} is offline.`,
            timestamp: new Date().toLocaleTimeString(),
          };
          setAlerts(prev => [newAlert, ...prev]);

          toast.error(`Service Critical: ${service.name} is now OFFLINE`, {
            description: `Domain: ${service.domain} | Language: ${service.language}`,
            icon: <XCircle className="text-rose-500" size={18} />,
            duration: 5000,
          });
        } else if (service.status === 'warning') {
          const alertId = `${service.id}-warning-${Date.now()}`;
          const newAlert: ServiceAlert = {
            id: alertId,
            serviceId: service.id,
            serviceName: service.name,
            status: 'warning',
            message: `DEGRADED: ${service.name} is experiencing high latency.`,
            timestamp: new Date().toLocaleTimeString(),
          };
          setAlerts(prev => [newAlert, ...prev]);

          toast.warning(`Service Warning: ${service.name} status changed to WARNING`, {
            description: `Latency: ${service.latency}ms | Domain: ${service.domain}`,
            icon: <AlertTriangle className="text-amber-500" size={18} />,
            duration: 4000,
          });
        } else if (service.status === 'online' && (prevStatus === 'offline' || prevStatus === 'warning')) {
          toast.success(`Service Restored: ${service.name} is back ONLINE`, {
            duration: 3000,
          });
        }
      }
      // Update ref for next check
      prevStatuses.current[service.id] = service.status;
    });
  }, [services]);

  const dismissAlert = (id: string) => {
    setAlerts(prev => prev.filter(a => a.id !== id));
  };

  const simulateIssue = () => {
    const randomIndex = Math.floor(Math.random() * services.length);
    const newServices = [...services];
    const service = newServices[randomIndex];
    
    // Cycle through statuses for simulation
    const nextStatus: Record<ServiceStatus, ServiceStatus> = {
      'online': 'warning',
      'warning': 'offline',
      'offline': 'online'
    };
    
    service.status = nextStatus[service.status];
    if (service.status === 'warning') service.latency = 450 + Math.floor(Math.random() * 500);
    if (service.status === 'online') service.latency = 10 + Math.floor(Math.random() * 50);
    
    setServices(newServices);
  };

  const filteredServices = services.filter(s => {
    const matchesFilter = filter === 'all' || s.status === filter;
    const matchesSearch = s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         s.domain.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Microservices Fleet</h2>
          <p className="text-slate-500 mt-1">Monitoring 1,000+ polyglot services across 12 clusters.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={simulateIssue}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 transition-colors font-medium shadow-sm"
          >
            <RefreshCw size={18} className="text-accent" />
            Simulate Issue
          </button>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search services..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent transition-all w-64"
            />
          </div>
          <div className="flex bg-white border border-slate-200 rounded-lg p-1 shadow-sm">
            {(['all', 'online', 'warning', 'offline'] as const).map((s) => (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className={cn(
                  "px-3 py-1 text-xs font-bold uppercase rounded-md transition-all",
                  filter === s 
                    ? "bg-slate-900 text-white" 
                    : "text-slate-500 hover:text-slate-900 hover:bg-slate-50"
                )}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Persistent Alert Banner */}
      <AnimatePresence>
        {alerts.length > 0 && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="space-y-2"
          >
            {alerts.map((alert) => (
              <motion.div
                key={alert.id}
                layout
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className={cn(
                  "flex items-center justify-between p-4 rounded-lg border shadow-sm",
                  alert.status === 'offline' 
                    ? "bg-rose-50 border-rose-200 text-rose-800" 
                    : "bg-amber-50 border-amber-200 text-amber-800"
                )}
              >
                <div className="flex items-center gap-3">
                  {alert.status === 'offline' ? <XCircle size={20} /> : <AlertTriangle size={20} />}
                  <div>
                    <p className="text-sm font-bold">{alert.message}</p>
                    <p className="text-xs opacity-70">Detected at {alert.timestamp}</p>
                  </div>
                </div>
                <button 
                  onClick={() => dismissAlert(alert.id)}
                  className="p-1 hover:bg-black/5 rounded-full transition-colors"
                >
                  <X size={18} />
                </button>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Healthy', value: services.filter(s => s.status === 'online').length, color: 'text-emerald-600', icon: Activity, type: 'online' },
          { label: 'Degraded', value: services.filter(s => s.status === 'warning').length, color: 'text-amber-600', icon: Cpu, type: 'warning' },
          { label: 'Critical', value: services.filter(s => s.status === 'offline').length, color: 'text-rose-600', icon: Globe, type: 'offline' },
          { label: 'Databases', value: '82', color: 'text-blue-600', icon: Database, type: 'all' },
        ].map((item, i) => (
          <button 
            key={item.label} 
            onClick={() => item.type !== 'all' && setFilter(item.type as any)}
            className={cn(
              "card flex items-center gap-4 text-left transition-all",
              filter === item.type ? "ring-2 ring-accent ring-offset-2" : ""
            )}
          >
            <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center bg-slate-50", item.color)}>
              <item.icon size={20} />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">{item.label}</p>
              <p className="text-xl font-bold">{item.value}</p>
            </div>
          </button>
        ))}
      </div>

      <div className="card overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-bottom border-slate-200">
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Service Name</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Domain</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Language</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Latency</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Uptime</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredServices.length > 0 ? filteredServices.map((service, i) => (
                <motion.tr 
                  key={service.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className={cn("w-2 h-2 rounded-full", service.status === 'online' ? "bg-emerald-500" : service.status === 'warning' ? "bg-amber-500" : "bg-rose-500")} />
                      <span className="font-mono text-sm font-medium">{service.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">{service.domain}</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-slate-100 rounded text-[10px] font-bold text-slate-600 uppercase">
                      {service.language}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "status-pill",
                      service.status === 'online' ? "status-online" : 
                      service.status === 'warning' ? "status-warning" : "status-offline"
                    )}>
                      {service.status}
                    </span>
                  </td>
                  <td className={cn(
                    "px-6 py-4 text-sm font-mono",
                    service.latency > 300 ? "text-rose-600 font-bold" : "text-slate-600"
                  )}>{service.latency > 0 ? `${service.latency}ms` : 'N/A'}</td>
                  <td className="px-6 py-4 text-sm text-slate-600">{service.uptime}</td>
                </motion.tr>
              )) : (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-500">
                    No services found matching the current filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
