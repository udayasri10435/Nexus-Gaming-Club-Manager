import React from 'react';
import { MOCK_TOURNAMENTS } from '../constants';
import { cn } from '../lib/utils';
import { Trophy, Users, Calendar, ArrowRight } from 'lucide-react';

export const Tournaments: React.FC = () => {
  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Tournaments</h2>
          <p className="text-slate-500 mt-1">Orchestrate events, brackets, and prize distributions.</p>
        </div>
        <button className="px-4 py-2 bg-accent text-white rounded-lg font-medium hover:bg-blue-600 transition-colors">
          Create Tournament
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {MOCK_TOURNAMENTS.map((t) => (
          <div key={t.id} className="card group cursor-pointer overflow-hidden relative">
            <div className={cn(
              "absolute top-0 right-0 w-32 h-32 -mr-8 -mt-8 rounded-full opacity-10 group-hover:scale-110 transition-transform",
              t.status === 'ongoing' ? "bg-emerald-500" : t.status === 'upcoming' ? "bg-blue-500" : "bg-slate-500"
            )} />
            
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-4">
                <span className={cn(
                  "text-[10px] font-bold uppercase px-2 py-0.5 rounded",
                  t.status === 'ongoing' ? "bg-emerald-100 text-emerald-700" :
                  t.status === 'upcoming' ? "bg-blue-100 text-blue-700" : "bg-slate-100 text-slate-600"
                )}>
                  {t.status}
                </span>
                <Trophy size={20} className={cn(
                  t.status === 'ongoing' ? "text-emerald-500" : t.status === 'upcoming' ? "text-blue-500" : "text-slate-400"
                )} />
              </div>

              <h3 className="text-xl font-bold text-slate-900 group-hover:text-accent transition-colors">{t.name}</h3>
              <p className="text-sm text-slate-500 mt-1">{t.game}</p>

              <div className="mt-6 space-y-3">
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Users size={16} className="text-slate-400" />
                  <span>{t.participants} Participants</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Calendar size={16} className="text-slate-400" />
                  <span>Starts in 2 days</span>
                </div>
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                  <span className="text-slate-400 font-normal">Prize Pool:</span>
                  <span className="text-emerald-600">{t.prizePool}</span>
                </div>
              </div>

              <button className="w-full mt-6 py-2 border border-slate-200 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-50 hover:border-slate-300 transition-all flex items-center justify-center gap-2">
                Manage Event
                <ArrowRight size={14} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
