import React from 'react';
import { MOCK_GAMES } from '../constants';
import { Star, Users, Play } from 'lucide-react';

export const Games: React.FC = () => {
  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Game Catalog</h2>
          <p className="text-slate-500 mt-1">Manage titles, assets, and server configurations.</p>
        </div>
        <button className="px-4 py-2 bg-accent text-white rounded-lg font-medium hover:bg-blue-600 transition-colors">
          Import Game
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {MOCK_GAMES.map((game) => (
          <div key={game.id} className="card p-0 overflow-hidden group">
            <div className="relative h-48 overflow-hidden">
              <img 
                src={game.image} 
                alt={game.title} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <button className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-accent shadow-xl">
                  <Play size={24} fill="currentColor" />
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">{game.genre}</span>
                <div className="flex items-center gap-1 text-amber-500">
                  <Star size={14} fill="currentColor" />
                  <span className="text-sm font-bold">{game.rating}</span>
                </div>
              </div>
              <h3 className="text-xl font-bold text-slate-900">{game.title}</h3>
              
              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Users size={16} className="text-slate-400" />
                  <span>{game.activePlayers} Active</span>
                </div>
                <button className="text-sm font-bold text-accent hover:underline">
                  Configure
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
