import React from 'react';
import { MOCK_MEMBERS } from '../constants';
import { cn } from '../lib/utils';
import { MoreHorizontal, Mail, Shield, Ban } from 'lucide-react';

export const Members: React.FC = () => {
  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Member Directory</h2>
          <p className="text-slate-500 mt-1">Manage club members, permissions, and status.</p>
        </div>
        <button className="px-4 py-2 bg-accent text-white rounded-lg font-medium hover:bg-blue-600 transition-colors">
          Add Member
        </button>
      </header>

      <div className="grid grid-cols-1 gap-4">
        {MOCK_MEMBERS.map((member) => (
          <div key={member.id} className="card flex items-center justify-between py-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-bold text-lg overflow-hidden">
                <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${member.username}`} alt={member.username} referrerPolicy="no-referrer" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900">{member.username}</h4>
                <p className="text-sm text-slate-500">{member.email}</p>
              </div>
            </div>

            <div className="hidden md:flex items-center gap-12">
              <div>
                <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Rank</p>
                <p className="text-sm font-medium text-slate-700">{member.rank}</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Joined</p>
                <p className="text-sm font-medium text-slate-700">{member.joinedDate}</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Status</p>
                <span className={cn(
                  "text-[10px] font-bold uppercase px-2 py-0.5 rounded",
                  member.status === 'active' ? "bg-emerald-100 text-emerald-700" :
                  member.status === 'inactive' ? "bg-slate-100 text-slate-600" : "bg-rose-100 text-rose-700"
                )}>
                  {member.status}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button className="p-2 text-slate-400 hover:text-accent hover:bg-slate-50 rounded-lg transition-all" title="Send Message">
                <Mail size={18} />
              </button>
              <button className="p-2 text-slate-400 hover:text-amber-600 hover:bg-slate-50 rounded-lg transition-all" title="Permissions">
                <Shield size={18} />
              </button>
              <button className="p-2 text-slate-400 hover:text-rose-600 hover:bg-slate-50 rounded-lg transition-all" title="Ban User">
                <Ban size={18} />
              </button>
              <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition-all">
                <MoreHorizontal size={18} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
